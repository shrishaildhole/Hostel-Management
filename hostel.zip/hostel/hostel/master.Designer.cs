﻿namespace hostel
{
    partial class master
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(master));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.hmsLabel = new System.Windows.Forms.Label();
            this.btnManageRooms = new System.Windows.Forms.Button();
            this.btnNewStudent = new System.Windows.Forms.Button();
            this.btnUpdateDeleteStudent = new System.Windows.Forms.Button();
            this.btnStudentFees = new System.Windows.Forms.Button();
            this.btnAllStudentLiving = new System.Windows.Forms.Button();
            this.btnLeavedStudents = new System.Windows.Forms.Button();
            this.btnNewEmployee = new System.Windows.Forms.Button();
            this.btnUpdateDeleteEmployee = new System.Windows.Forms.Button();
            this.btnEmployeePayment = new System.Windows.Forms.Button();
            this.btnAllEmployeeWorking = new System.Windows.Forms.Button();
            this.btnLeavedEmployee = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(329, 100);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1476, 814);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Mistral", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(32, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 43);
            this.label1.TabIndex = 1;
            this.label1.Text = "NAVIGATOR BAR";
            // 
            // hmsLabel
            // 
            this.hmsLabel.AutoSize = true;
            this.hmsLabel.Font = new System.Drawing.Font("Chiller", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hmsLabel.ForeColor = System.Drawing.Color.White;
            this.hmsLabel.Location = new System.Drawing.Point(472, 17);
            this.hmsLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.hmsLabel.Name = "hmsLabel";
            this.hmsLabel.Size = new System.Drawing.Size(648, 69);
            this.hmsLabel.TabIndex = 2;
            this.hmsLabel.Text = "HOSTEL MANAGEMENT SYSTEM";
            this.hmsLabel.Click += new System.EventHandler(this.hmsLabel_Click);
            // 
            // btnManageRooms
            // 
            this.btnManageRooms.BackColor = System.Drawing.Color.Gray;
            this.btnManageRooms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageRooms.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageRooms.ForeColor = System.Drawing.Color.White;
            this.btnManageRooms.Image = ((System.Drawing.Image)(resources.GetObject("btnManageRooms.Image")));
            this.btnManageRooms.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnManageRooms.Location = new System.Drawing.Point(16, 100);
            this.btnManageRooms.Margin = new System.Windows.Forms.Padding(4);
            this.btnManageRooms.Name = "btnManageRooms";
            this.btnManageRooms.Size = new System.Drawing.Size(281, 49);
            this.btnManageRooms.TabIndex = 3;
            this.btnManageRooms.Text = "Manage Rooms";
            this.btnManageRooms.UseVisualStyleBackColor = false;
            this.btnManageRooms.Click += new System.EventHandler(this.btnManageRooms_Click);
            // 
            // btnNewStudent
            // 
            this.btnNewStudent.BackColor = System.Drawing.Color.Gray;
            this.btnNewStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewStudent.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewStudent.ForeColor = System.Drawing.Color.White;
            this.btnNewStudent.Image = ((System.Drawing.Image)(resources.GetObject("btnNewStudent.Image")));
            this.btnNewStudent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNewStudent.Location = new System.Drawing.Point(16, 169);
            this.btnNewStudent.Margin = new System.Windows.Forms.Padding(4);
            this.btnNewStudent.Name = "btnNewStudent";
            this.btnNewStudent.Size = new System.Drawing.Size(281, 49);
            this.btnNewStudent.TabIndex = 4;
            this.btnNewStudent.Text = "New Student";
            this.btnNewStudent.UseVisualStyleBackColor = false;
            this.btnNewStudent.Click += new System.EventHandler(this.btnNewStudent_Click);
            // 
            // btnUpdateDeleteStudent
            // 
            this.btnUpdateDeleteStudent.BackColor = System.Drawing.Color.Gray;
            this.btnUpdateDeleteStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateDeleteStudent.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateDeleteStudent.ForeColor = System.Drawing.Color.White;
            this.btnUpdateDeleteStudent.Image = ((System.Drawing.Image)(resources.GetObject("btnUpdateDeleteStudent.Image")));
            this.btnUpdateDeleteStudent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdateDeleteStudent.Location = new System.Drawing.Point(16, 241);
            this.btnUpdateDeleteStudent.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdateDeleteStudent.Name = "btnUpdateDeleteStudent";
            this.btnUpdateDeleteStudent.Size = new System.Drawing.Size(281, 49);
            this.btnUpdateDeleteStudent.TabIndex = 5;
            this.btnUpdateDeleteStudent.Text = "Update & Delete Students";
            this.btnUpdateDeleteStudent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdateDeleteStudent.UseVisualStyleBackColor = false;
            this.btnUpdateDeleteStudent.Click += new System.EventHandler(this.btnUpdateDeleteStudent_Click);
            // 
            // btnStudentFees
            // 
            this.btnStudentFees.BackColor = System.Drawing.Color.Gray;
            this.btnStudentFees.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStudentFees.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStudentFees.ForeColor = System.Drawing.Color.White;
            this.btnStudentFees.Image = ((System.Drawing.Image)(resources.GetObject("btnStudentFees.Image")));
            this.btnStudentFees.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStudentFees.Location = new System.Drawing.Point(16, 313);
            this.btnStudentFees.Margin = new System.Windows.Forms.Padding(4);
            this.btnStudentFees.Name = "btnStudentFees";
            this.btnStudentFees.Size = new System.Drawing.Size(281, 49);
            this.btnStudentFees.TabIndex = 6;
            this.btnStudentFees.Text = "Student Fees";
            this.btnStudentFees.UseVisualStyleBackColor = false;
            this.btnStudentFees.Click += new System.EventHandler(this.btnStudentFees_Click);
            // 
            // btnAllStudentLiving
            // 
            this.btnAllStudentLiving.BackColor = System.Drawing.Color.Gray;
            this.btnAllStudentLiving.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAllStudentLiving.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAllStudentLiving.ForeColor = System.Drawing.Color.White;
            this.btnAllStudentLiving.Image = ((System.Drawing.Image)(resources.GetObject("btnAllStudentLiving.Image")));
            this.btnAllStudentLiving.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAllStudentLiving.Location = new System.Drawing.Point(16, 384);
            this.btnAllStudentLiving.Margin = new System.Windows.Forms.Padding(4);
            this.btnAllStudentLiving.Name = "btnAllStudentLiving";
            this.btnAllStudentLiving.Size = new System.Drawing.Size(281, 49);
            this.btnAllStudentLiving.TabIndex = 7;
            this.btnAllStudentLiving.Text = "All Student Living";
            this.btnAllStudentLiving.UseVisualStyleBackColor = false;
            this.btnAllStudentLiving.Click += new System.EventHandler(this.btnAllStudentLiving_Click);
            // 
            // btnLeavedStudents
            // 
            this.btnLeavedStudents.BackColor = System.Drawing.Color.Gray;
            this.btnLeavedStudents.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLeavedStudents.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeavedStudents.ForeColor = System.Drawing.Color.White;
            this.btnLeavedStudents.Image = ((System.Drawing.Image)(resources.GetObject("btnLeavedStudents.Image")));
            this.btnLeavedStudents.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLeavedStudents.Location = new System.Drawing.Point(16, 460);
            this.btnLeavedStudents.Margin = new System.Windows.Forms.Padding(4);
            this.btnLeavedStudents.Name = "btnLeavedStudents";
            this.btnLeavedStudents.Size = new System.Drawing.Size(281, 49);
            this.btnLeavedStudents.TabIndex = 8;
            this.btnLeavedStudents.Text = "Leaved Student";
            this.btnLeavedStudents.UseVisualStyleBackColor = false;
            this.btnLeavedStudents.Click += new System.EventHandler(this.btnLeavedStudents_Click);
            // 
            // btnNewEmployee
            // 
            this.btnNewEmployee.BackColor = System.Drawing.Color.Gray;
            this.btnNewEmployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewEmployee.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewEmployee.ForeColor = System.Drawing.Color.White;
            this.btnNewEmployee.Image = ((System.Drawing.Image)(resources.GetObject("btnNewEmployee.Image")));
            this.btnNewEmployee.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNewEmployee.Location = new System.Drawing.Point(16, 533);
            this.btnNewEmployee.Margin = new System.Windows.Forms.Padding(4);
            this.btnNewEmployee.Name = "btnNewEmployee";
            this.btnNewEmployee.Size = new System.Drawing.Size(281, 49);
            this.btnNewEmployee.TabIndex = 9;
            this.btnNewEmployee.Text = "New Employee";
            this.btnNewEmployee.UseVisualStyleBackColor = false;
            this.btnNewEmployee.Click += new System.EventHandler(this.btnNewEmployee_Click);
            // 
            // btnUpdateDeleteEmployee
            // 
            this.btnUpdateDeleteEmployee.BackColor = System.Drawing.Color.Gray;
            this.btnUpdateDeleteEmployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateDeleteEmployee.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateDeleteEmployee.ForeColor = System.Drawing.Color.White;
            this.btnUpdateDeleteEmployee.Image = ((System.Drawing.Image)(resources.GetObject("btnUpdateDeleteEmployee.Image")));
            this.btnUpdateDeleteEmployee.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdateDeleteEmployee.Location = new System.Drawing.Point(16, 608);
            this.btnUpdateDeleteEmployee.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdateDeleteEmployee.Name = "btnUpdateDeleteEmployee";
            this.btnUpdateDeleteEmployee.Size = new System.Drawing.Size(281, 49);
            this.btnUpdateDeleteEmployee.TabIndex = 10;
            this.btnUpdateDeleteEmployee.Text = "Update & Delete Employee";
            this.btnUpdateDeleteEmployee.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdateDeleteEmployee.UseVisualStyleBackColor = false;
            this.btnUpdateDeleteEmployee.Click += new System.EventHandler(this.btnUpdateDeleteEmployee_Click);
            // 
            // btnEmployeePayment
            // 
            this.btnEmployeePayment.BackColor = System.Drawing.Color.Gray;
            this.btnEmployeePayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEmployeePayment.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployeePayment.ForeColor = System.Drawing.Color.White;
            this.btnEmployeePayment.Image = ((System.Drawing.Image)(resources.GetObject("btnEmployeePayment.Image")));
            this.btnEmployeePayment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEmployeePayment.Location = new System.Drawing.Point(16, 681);
            this.btnEmployeePayment.Margin = new System.Windows.Forms.Padding(4);
            this.btnEmployeePayment.Name = "btnEmployeePayment";
            this.btnEmployeePayment.Size = new System.Drawing.Size(281, 49);
            this.btnEmployeePayment.TabIndex = 11;
            this.btnEmployeePayment.Text = "Employee Payment";
            this.btnEmployeePayment.UseVisualStyleBackColor = false;
            this.btnEmployeePayment.Click += new System.EventHandler(this.btnEmployeePayment_Click);
            // 
            // btnAllEmployeeWorking
            // 
            this.btnAllEmployeeWorking.BackColor = System.Drawing.Color.Gray;
            this.btnAllEmployeeWorking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAllEmployeeWorking.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAllEmployeeWorking.ForeColor = System.Drawing.Color.White;
            this.btnAllEmployeeWorking.Image = ((System.Drawing.Image)(resources.GetObject("btnAllEmployeeWorking.Image")));
            this.btnAllEmployeeWorking.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAllEmployeeWorking.Location = new System.Drawing.Point(16, 753);
            this.btnAllEmployeeWorking.Margin = new System.Windows.Forms.Padding(4);
            this.btnAllEmployeeWorking.Name = "btnAllEmployeeWorking";
            this.btnAllEmployeeWorking.Size = new System.Drawing.Size(281, 49);
            this.btnAllEmployeeWorking.TabIndex = 12;
            this.btnAllEmployeeWorking.Text = "All Employee Working";
            this.btnAllEmployeeWorking.UseVisualStyleBackColor = false;
            this.btnAllEmployeeWorking.Click += new System.EventHandler(this.btnAllEmployeeWorking_Click);
            // 
            // btnLeavedEmployee
            // 
            this.btnLeavedEmployee.BackColor = System.Drawing.Color.Gray;
            this.btnLeavedEmployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLeavedEmployee.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeavedEmployee.ForeColor = System.Drawing.Color.White;
            this.btnLeavedEmployee.Image = ((System.Drawing.Image)(resources.GetObject("btnLeavedEmployee.Image")));
            this.btnLeavedEmployee.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLeavedEmployee.Location = new System.Drawing.Point(16, 828);
            this.btnLeavedEmployee.Margin = new System.Windows.Forms.Padding(4);
            this.btnLeavedEmployee.Name = "btnLeavedEmployee";
            this.btnLeavedEmployee.Size = new System.Drawing.Size(281, 49);
            this.btnLeavedEmployee.TabIndex = 13;
            this.btnLeavedEmployee.Text = "Leaved Employee";
            this.btnLeavedEmployee.UseVisualStyleBackColor = false;
            this.btnLeavedEmployee.Click += new System.EventHandler(this.btnLeavedEmployee_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.BackColor = System.Drawing.Color.Gray;
            this.btnLogOut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogOut.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogOut.ForeColor = System.Drawing.Color.White;
            this.btnLogOut.Image = ((System.Drawing.Image)(resources.GetObject("btnLogOut.Image")));
            this.btnLogOut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogOut.Location = new System.Drawing.Point(1184, 17);
            this.btnLogOut.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(200, 62);
            this.btnLogOut.TabIndex = 14;
            this.btnLogOut.Text = "Log Out";
            this.btnLogOut.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLogOut.UseVisualStyleBackColor = false;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Gray;
            this.button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button12.Location = new System.Drawing.Point(1418, 26);
            this.button12.Margin = new System.Windows.Forms.Padding(4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(53, 49);
            this.button12.TabIndex = 15;
            this.button12.Text = "X";
            this.button12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // master
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1827, 897);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnLeavedEmployee);
            this.Controls.Add(this.btnAllEmployeeWorking);
            this.Controls.Add(this.btnEmployeePayment);
            this.Controls.Add(this.btnUpdateDeleteEmployee);
            this.Controls.Add(this.btnNewEmployee);
            this.Controls.Add(this.btnLeavedStudents);
            this.Controls.Add(this.btnAllStudentLiving);
            this.Controls.Add(this.btnStudentFees);
            this.Controls.Add(this.btnUpdateDeleteStudent);
            this.Controls.Add(this.btnNewStudent);
            this.Controls.Add(this.btnManageRooms);
            this.Controls.Add(this.hmsLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "master";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "master";
            this.Load += new System.EventHandler(this.master_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label hmsLabel;
        private System.Windows.Forms.Button btnManageRooms;
        private System.Windows.Forms.Button btnNewStudent;
        private System.Windows.Forms.Button btnUpdateDeleteStudent;
        private System.Windows.Forms.Button btnStudentFees;
        private System.Windows.Forms.Button btnAllStudentLiving;
        private System.Windows.Forms.Button btnLeavedStudents;
        private System.Windows.Forms.Button btnNewEmployee;
        private System.Windows.Forms.Button btnUpdateDeleteEmployee;
        private System.Windows.Forms.Button btnEmployeePayment;
        private System.Windows.Forms.Button btnAllEmployeeWorking;
        private System.Windows.Forms.Button btnLeavedEmployee;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button button12;
        //private System.Windows.Forms.Timer timer1;
    }
}