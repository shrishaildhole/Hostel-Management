﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hostel
{
    public partial class Form1 : Form
    {
        private const string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HP\OneDrive\Desktop\hostel\Database\hostel.mdf;Integrated Security=True;Connect Timeout=30";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = txtusername.Text;
            string password = txtpassword.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Both username and password are required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LoginResult result = IsValidLogin(username, password);

            switch (result)
            {
                case LoginResult.Valid:
                    MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // You can navigate to the main application form or perform other actions here.
                    master ms = new master();
                    this.Hide();
                    ms.Show();
                    break;
                case LoginResult.WrongPassword:
                    MessageBox.Show("Wrong password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case LoginResult.WrongUsername:
                    MessageBox.Show("Wrong username.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
                case LoginResult.Invalid:
                    MessageBox.Show("Wrong username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }
        private LoginResult IsValidLogin(string username, string password)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                string query = "SELECT Password FROM login WHERE Username = @username";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@username", username);

                string storedPassword = (string)command.ExecuteScalar();

                if (storedPassword == null)
                {
                    return LoginResult.WrongUsername;
                }

                if (storedPassword == password)
                {
                    return LoginResult.Valid;
                }
                else
                {
                    return LoginResult.WrongPassword;
                }
            }
        }
        private enum LoginResult
        {
            Valid,
            WrongPassword,
            WrongUsername,
            Invalid
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}